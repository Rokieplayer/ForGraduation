import torch
import torch.nn as nn
import dgl
import random
import numpy as np
import util.mol_conv as mc
from model import GCN
from model import EGCN
from util import trainer
from model import FNN_EGCN
from model import skip_EGCN
from model import GResNet_EGCN
from model import GResNet_FNN_EGCN



# check GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# experiment parameters
dataset_name = 'esol'
batch_size = 32
max_epochs = 300
k = 5
#에포크300이 원래 값

def collate(samples):
    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(labels, dtype=torch.float32).view(-1, 1).to(device)


def collate_emodel_scale(samples):
    self_feats = np.empty((len(samples), 1), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_atoms
        self_feats[i, 1] = mol_graph.weight

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels).view(-1, 1).to(device)


def collate_emodel_ring(samples):
    self_feats = np.empty((len(samples), 1), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_rings

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels).view(-1, 1).to(device)


def collate_emodel(samples):
    self_feats = np.empty((len(samples), mc.dim_self_feat), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_atoms
        self_feats[i, 1] = mol_graph.weight
        self_feats[i, 2] = mol_graph.num_rings

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels, dtype=torch.float32).to(device)



# load train, validation, and test datasets
print('Data loading...')
dataset = mc.read_dataset('data/' + dataset_name + '.csv')
random.shuffle(dataset)

# define model
#model_GCN = GCN.Net(mc.dim_atomic_feat, 1).to(device)
model_EGCN = EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_FNN_EGCN = FNN_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_skip_EGCN = skip_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_EGCN = GResNet_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_FNN_EGCN = GResNet_FNN_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)




# define loss function
criterion = nn.L1Loss(reduction='sum')


# train and evaluate competitors
test_losses = dict()


print('--------- EGCN ---------')
test_losses['EGCN'] = trainer.cross_validation(dataset, model_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
print('test loss (EGCN): ' + str(test_losses['EGCN']))

print('--------- FNN_EGCN ---------')
test_losses['FNN_EGCN'] = trainer.cross_validation(dataset, model_FNN_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
print('test loss (FNN_EGCN): ' + str(test_losses['FNN_EGCN']))

print('--------- skip_EGCN ---------')
test_losses['skip_EGCN'] = trainer.cross_validation(dataset, model_skip_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
print('test loss (skip_EGCN): ' + str(test_losses['skip_EGCN']))

print('--------- GResNet_EGCN(naive) ---------')
test_losses['GResNet_EGCN'] = trainer.cross_validation(dataset, model_GResNet_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
print('test loss (GResNet_EGCN): ' + str(test_losses['GResNet_EGCN']))

print('--------- GResNet_FNN_EGCN(naive) ---------')
test_losses['GResNet_FNN_EGCN'] = trainer.cross_validation(dataset, model_GResNet_FNN_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
print('test loss (GResNet_FNN_EGCN): ' + str(test_losses['GResNet_FNN_EGCN']))


print(test_losses)
