import torch
import torch.nn as nn
import dgl
import random
import numpy as np
import util.mol_conv as mc
from model import GCN
from model import EGCN
from util import trainer

from model import FNN_EGCN
from model import skip_EGCN
from model import GResNet_EGCN
from model import GResNet_FNN_EGCN
from model import Depthwise_Separable_EGCN
from model import GED
from model import GResNet_EGCN_Short
from model import Short_GED


from model import GResNet_1
from model import GResNet_2
from model import GResNet_3
from model import Very_Short_GED
from model import Very_Short_GED_3

from model import raw_2
from model import raw_3
from model import raw_6
# check GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# experiment parameters
dataset_name = 'qm8_f1'
batch_size = 256
max_epochs = 300
k = 5
#에포크300이 원래 값

def collate(samples):
    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(labels, dtype=torch.float32).view(-1, 1).to(device)


def collate_emodel_scale(samples):
    self_feats = np.empty((len(samples), 1), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_atoms
        self_feats[i, 1] = mol_graph.weight

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels).view(-1, 1).to(device)


def collate_emodel_ring(samples):
    self_feats = np.empty((len(samples), 1), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_rings

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels).view(-1, 1).to(device)


def collate_emodel(samples):
    self_feats = np.empty((len(samples), mc.dim_self_feat), dtype=np.float32)

    for i in range(0, len(samples)):
        mol_graph = samples[i][0]
        self_feats[i, 0] = mol_graph.num_atoms
        self_feats[i, 1] = mol_graph.weight
        self_feats[i, 2] = mol_graph.num_rings

    graphs, labels = map(list, zip(*samples))
    batched_graph = dgl.batch(graphs)

    return batched_graph, torch.tensor(self_feats).to(device), torch.tensor(labels, dtype=torch.float32).to(device)



# load train, validation, and test datasets
print('Data loading...')
dataset = mc.read_dataset('data/' + dataset_name + '.csv')
random.shuffle(dataset)

# define model
#model_GCN = GCN.Net(mc.dim_atomic_feat, 1).to(device)
model_EGCN = EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_FNN_EGCN = FNN_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_skip_EGCN = skip_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_EGCN = GResNet_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_FNN_EGCN = GResNet_FNN_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_Depth_Separable_EGCN = Depthwise_Separable_EGCN.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GED = GED.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_EGCN_Short = GResNet_EGCN_Short.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_Short_GED = Short_GED.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)

model_GResNet_1 = GResNet_1.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_2 = GResNet_2.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_GResNet_3 = GResNet_3.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)

model_raw_2 = raw_2.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_raw_3 = raw_3.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_raw_6 = raw_6.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_Very_Short_GED = Very_Short_GED.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)
model_Very_Short_GED_3 = Very_Short_GED_3.Net(mc.dim_atomic_feat, 1, mc.dim_self_feat).to(device)



# define loss function
criterion = nn.L1Loss(reduction='sum')

#criterion = nn.MSELoss(reduction = 'sum')


# train and evaluate competitors
test_losses = dict()


# print('--------- EGCN ---------')
# test_losses['EGCN'] = trainer.cross_validation(dataset, model_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (EGCN): ' + str(test_losses['EGCN']))



# print('--------- skip_EGCN ---------')
# test_losses['skip_EGCN'] = trainer.cross_validation(dataset, model_skip_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (skip_EGCN): ' + str(test_losses['skip_EGCN']))

# print('--------- GResNet_EGCN(naive) ---------')
# test_losses['GResNet_EGCN'] = trainer.cross_validation(dataset, model_GResNet_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GResNet_EGCN): ' + str(test_losses['GResNet_EGCN']))



# print('--------- Depth Separable EGCN ---------')
# test_losses['Depth Separable EGCN'] = trainer.cross_validation(dataset, model_Depth_Separable_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (Depth Separable EGCN): ' + str(test_losses['Depth Separable EGCN']))


# print('--------- GED ---------')
# test_losses['GED'] = trainer.cross_validation(dataset, model_GED, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GED): ' + str(test_losses['GED']))

# print('--------- GResNet_EGCN_Short ---------')
# test_losses['GResNet_EGCN_Short'] = trainer.cross_validation(dataset, model_GResNet_EGCN_Short, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GResNet_EGCN_Short): ' + str(test_losses['GResNet_EGCN_Short']))

# print('--------- Short_GED ---------')
# test_losses['Short_GED'] = trainer.cross_validation(dataset, model_Short_GED, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (Short_GED): ' + str(test_losses['Short_GED']))


# print('--------- GResNet_1 ---------')
# test_losses['GResNet_1'] = trainer.cross_validation(dataset, model_GResNet_1, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GResNet_1): ' + str(test_losses['GResNet_1']))

# print('--------- GResNet_2 ---------')
# test_losses['GResNet_2'] = trainer.cross_validation(dataset, model_GResNet_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GResNet_2): ' + str(test_losses['GResNet_2']))

# print('--------- GResNet_3 ---------')
# test_losses['GResNet_3'] = trainer.cross_validation(dataset, model_GResNet_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (GResNet_3): ' + str(test_losses['GResNet_3']))



# print('--------- raw_2 ---------')
# test_losses['raw_2'] = trainer.cross_validation(dataset, model_raw_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (raw_2): ' + str(test_losses['raw_2']))

# print('--------- raw_3 ---------')
# test_losses['raw_3'] = trainer.cross_validation(dataset, model_raw_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (raw_3): ' + str(test_losses['raw_3']))

# print('--------- raw_6 ---------')
# test_losses['raw_6'] = trainer.cross_validation(dataset, model_raw_6, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
# print('test loss (raw_6): ' + str(test_losses['raw_6']))







def result(list, name, time):
    ni = np.array(list)
    di = {}
    di['model'] = name
    di['average'] = np.mean(ni)
    di['std'] = np.std(ni)
    di['max'] = np.amax(ni)
    di['min'] = np.amin(ni)
    di['length'] = di['max'] - di['min'] 
    di['avg_time'] = time
    return di





trial = 10
tax = 0.0
import time
list_1 = []
list_2 = []

print('--------- EGCN ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax = trainer.cross_validation(dataset, model_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'EGCN', time_1))



print('--------- GResNet_EGCN(naive) ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax = trainer.cross_validation(dataset,  model_GResNet_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'GResNet_EGCN(naive)', time_1))

print('--------- GResNet_EGCN_Short ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_EGCN_Short, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_EGCN_Short', time_1))


print('--------- GResNet_1 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_1, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_1', time_1))


print('--------- GResNet_2 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_2', time_1))

print('--------- GResNet_3 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'GResNet_3', time_1))


print('--------- raw_2 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_2', time_1))


print('--------- raw_3 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_3', time_1))


print('--------- raw_6 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_6, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_6', time_1))




print('--------- GED ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GED, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'GED', time_1))

print('--------- Short_GED---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_Short_GED, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'Short_GED', time_1))

print('--------- Very_Short_GED---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_Very_Short_GED, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'Very_Short_GED', time_1))

print('--------- Very_Short_GED_3---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_Very_Short_GED_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'Very_Short_GED_3', time_1))

for i in range(13):
    print(list_2[i])
    print('\n')


    # GED_3까지 13개다.