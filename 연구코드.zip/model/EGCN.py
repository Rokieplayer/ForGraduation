import dgl.function as fn
import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl



msg = fn.copy_src(src='h', out='m')


def reduce(nodes):
    accum = torch.mean(nodes.mailbox['m'], 1)

    return {'h': accum}


class NodeApplyModule(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(NodeApplyModule, self).__init__()
        self.linear = nn.Linear(dim_in, dim_out)

    def forward(self, node):
        h = self.linear(node.data['h'])

        return {'h': h}


class GCNLayer(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(GCNLayer, self).__init__()
        self.apply_mod = NodeApplyModule(dim_in, dim_out)

    def forward(self, g, feature):
        g.ndata['h'] = feature
        g.update_all(msg, reduce)
        g.apply_nodes(func=self.apply_mod)

        return g.ndata.pop('h')

#원래의 Net

class Net(nn.Module):
    def __init__(self, dim_in, dim_out, dim_self_feat):
        super(Net, self).__init__()

        self.gc1 = GCNLayer(dim_in, 100)
        self.gc2 = GCNLayer(100, 20)
        self.fc1 = nn.Linear(20 + dim_self_feat, 10)
        self.fc2 = nn.Linear(10, dim_out)

    def forward(self, g, self_feat):
        h = F.relu(self.gc1(g, g.ndata['feat']))
        h = F.relu(self.gc2(g, h))
        g.ndata['h'] = h

        hg = dgl.mean_nodes(g, 'h')
        hg = torch.cat((hg, self_feat), dim=1)

        out = F.relu(self.fc1(hg))
        out = self.fc2(out)

        return out




#논문의 컨셉을 FNN에 확장한 것

# class Net(nn.Module):
#     def __init__(self, dim_in, dim_out, dim_self_feat):
#         super(Net, self).__init__()

#         self.gc1 = GCNLayer(dim_in, 100)
#         self.gc2 = GCNLayer(100, 20)
#         self.fc1 = nn.Linear(20 + dim_self_feat, 10)
#         self.fc2 = nn.Linear(10 + dim_self_feat, 4)
#         self.fc3 = nn.Linear(4 + dim_self_feat, 2)
#         self.fc4 = nn.Linear(2, dim_out)

#     def forward(self, g, self_feat):
       
#         h = F.relu(self.gc1(g, g.ndata['feat']))
       
#         h = F.relu(self.gc2(g, h))
        
#         g.ndata['h'] = h

#         hg = dgl.mean_nodes(g, 'h')
#         hg = torch.cat((hg, self_feat), dim=1)

#         hg = F.relu(self.fc1(hg))
#         hg = torch.cat((hg, self_feat), dim=1)
#         hg = F.relu(self.fc2(hg))
#         hg = torch.cat((hg, self_feat), dim=1)
#         hg = F.relu(self.fc3(hg))
#         hg = self.fc4(hg)

#         return hg
 

 # skip connection 이용

# class Net(nn.Module):
#     def __init__(self, dim_in, dim_out, dim_self_feat):
#         super(Net, self).__init__()

#         self.gc1 = GCNLayer(dim_in, 100)
#         self.gc2 = GCNLayer(100, 64)
#         self.gc3 = GCNLayer(64 + 100, 64)
#         self.gc4 = GCNLayer(64, 20)
#         self.fc1 = nn.Linear(20 + dim_self_feat, 10)
#         self.fc2 = nn.Linear(10, dim_out)

#     def forward(self, g, self_feat):
#         h1 = F.relu(self.gc1(g, g.ndata['feat']))
#         h2 = F.relu(self.gc2(g, h1))
#         h2m = torch.cat([h1, h2],dim=1)
#         h3 = F.relu(self.gc3(g, h2m))
#         h4 = F.relu(self.gc4(g, h3))
        
#         g.ndata['h'] = h4

#         hg = dgl.mean_nodes(g, 'h')
#         hg = torch.cat((hg, self_feat), dim=1)

#         out = F.relu(self.fc1(hg))
#         out = self.fc2(out)

#         return out


# ResNet() 어느 종류인지 모르겠다. FNN파트는 안 건든다. naive 같음

# class Net(nn.Module):
#     def __init__(self, dim_in, dim_out, dim_self_feat):
#         super(Net, self).__init__()

#         self.gc1 = GCNLayer(dim_in, 100)
#         self.gc2 = GCNLayer(100 + dim_in, 128)
#         self.gc3 = GCNLayer(128 + 100 , 128)
#         self.gc4 = GCNLayer(128 + 128, 64)
#         self.gc5 = GCNLayer(128+64, 64)
#         self.gc6 = GCNLayer(64 + 64, 32)
#         self.gc7 = GCNLayer(64 + 32, 32)
#         self.gc8 = GCNLayer(64, 16)
#         self.gc9 = GCNLayer(32 + 16, 8)
#         self.gc10 = GCNLayer(24, 12)



#         self.fc1 = nn.Linear(20 + dim_self_feat, 10)
#         self.fc2 = nn.Linear(10, dim_out)

#     def forward(self, g, self_feat):
#         I = g.ndata['feat']
#         h1 = F.relu(self.gc1(g, I))
#         h1m = torch.cat([h1, I],dim=1)
#         h2 = F.relu(self.gc2(g, h1m))
#         h2m = torch.cat([h2, h1],dim=1)
#         h3 = F.relu(self.gc3(g, h2m))

#         h3m = torch.cat([h3, h2],dim=1)
#         h4 = F.relu(self.gc4(g, h3m))

#         h4m = torch.cat([h4, h3],dim=1)
#         h5 = F.relu(self.gc5(g, h4m))

#         h5m = torch.cat([h5, h4],dim=1)
#         h6 = F.relu(self.gc6(g, h5m))

#         h6m = torch.cat([h6, h5],dim=1)
#         h7 = F.relu(self.gc7(g, h6m))

#         h7m = torch.cat([h7, h6],dim=1)
#         h8 = F.relu(self.gc8(g, h7m))

#         h8m = torch.cat([h8, h7],dim=1)
#         h9 = F.relu(self.gc9(g, h8m))

#         h9m = torch.cat([h9, h8],dim=1)
#         h10 = F.relu(self.gc10(g, h9m))

#         h10m = torch.cat([h10, h9],dim=1)



        
        
#         g.ndata['h'] = h10m

#         hg = dgl.mean_nodes(g, 'h')
#         hg = torch.cat((hg, self_feat), dim=1)

#         out = F.relu(self.fc1(hg))
#         out = self.fc2(out)

#         return out

# ResNet() 어느 종류인지 모르겠다. naive 같음, 이번엔 FNN파트를 위처럼 확장한다.

# class Net(nn.Module):
#     def __init__(self, dim_in, dim_out, dim_self_feat):
#         super(Net, self).__init__()

#         self.gc1 = GCNLayer(dim_in, 100)
#         self.gc2 = GCNLayer(100 + dim_in, 128)
#         self.gc3 = GCNLayer(128 + 100 , 128)
#         self.gc4 = GCNLayer(128 + 128, 64)
#         self.gc5 = GCNLayer(128+64, 64)
#         self.gc6 = GCNLayer(64 + 64, 32)
#         self.gc7 = GCNLayer(64 + 32, 32)
#         self.gc8 = GCNLayer(64, 16)
#         self.gc9 = GCNLayer(32 + 16, 8)
#         self.gc10 = GCNLayer(24, 12)

#         self.fc1 = nn.Linear(20 + dim_self_feat, 10)
#         self.fc2 = nn.Linear(10 + dim_self_feat, 4)
#         self.fc3 = nn.Linear(4 + dim_self_feat, 2)
#         self.fc4 = nn.Linear(2, dim_out)

        

#     def forward(self, g, self_feat):
#         I = g.ndata['feat']
#         h1 = F.relu(self.gc1(g, I))
#         h1m = torch.cat([h1, I],dim=1)
#         h2 = F.relu(self.gc2(g, h1m))
#         h2m = torch.cat([h2, h1],dim=1)
#         h3 = F.relu(self.gc3(g, h2m))

#         h3m = torch.cat([h3, h2],dim=1)
#         h4 = F.relu(self.gc4(g, h3m))

#         h4m = torch.cat([h4, h3],dim=1)
#         h5 = F.relu(self.gc5(g, h4m))

#         h5m = torch.cat([h5, h4],dim=1)
#         h6 = F.relu(self.gc6(g, h5m))

#         h6m = torch.cat([h6, h5],dim=1)
#         h7 = F.relu(self.gc7(g, h6m))

#         h7m = torch.cat([h7, h6],dim=1)
#         h8 = F.relu(self.gc8(g, h7m))

#         h8m = torch.cat([h8, h7],dim=1)
#         h9 = F.relu(self.gc9(g, h8m))

#         h9m = torch.cat([h9, h8],dim=1)
#         h10 = F.relu(self.gc10(g, h9m))

#         h10m = torch.cat([h10, h9],dim=1)



        
        
#         g.ndata['h'] = h10m

#         hg = dgl.mean_nodes(g, 'h')
#         hg = torch.cat((hg, self_feat), dim=1)

#         hg = F.relu(self.fc1(hg))
#         hg = torch.cat((hg, self_feat), dim=1)
#         hg = F.relu(self.fc2(hg))
#         hg = torch.cat((hg, self_feat), dim=1)
#         hg = F.relu(self.fc3(hg))
#         hg = self.fc4(hg)

#         return hg
