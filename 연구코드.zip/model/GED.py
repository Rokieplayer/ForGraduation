import dgl.function as fn
import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl


msg = fn.copy_src(src='h', out='m')


def reduce(nodes):
    accum = torch.mean(nodes.mailbox['m'], 1)

    return {'h': accum}


class NodeApplyModule(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(NodeApplyModule, self).__init__()
        self.linear = nn.Linear(dim_in, dim_out)

    def forward(self, node):
        h = self.linear(node.data['h'])

        return {'h': h}


class GCNLayer(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(GCNLayer, self).__init__()
        self.apply_mod = NodeApplyModule(dim_in, dim_out)

    def forward(self, g, feature):
        g.ndata['h'] = feature
        g.update_all(msg, reduce)
        g.apply_nodes(func=self.apply_mod)

        return g.ndata.pop('h')



# GResNet과 Depthwise 을 동시에 씀  short 아님.

class Net(nn.Module):
    def __init__(self, dim_in, dim_out, dim_self_feat):
        super(Net, self).__init__()

        self.gc1 = GCNLayer(dim_in, 100)
        self.gc2 = GCNLayer(100, 20)

        self.ggc1 = GCNLayer(dim_in, 100)
        self.ggc2 = GCNLayer(100 + dim_in, 128)
        self.ggc3 = GCNLayer(128 + 100 , 128)
        self.ggc4 = GCNLayer(128 + 128, 64)
        self.ggc5 = GCNLayer(128+64, 64)
        self.ggc6 = GCNLayer(64 + 64, 32)
        self.ggc7 = GCNLayer(64 + 32, 32)
        self.ggc8 = GCNLayer(64, 16)
        self.ggc9 = GCNLayer(32 + 16, 8)
        self.ggc10 = GCNLayer(24, 12)












        
        self.ggg = GCNLayer(40, 20)
        
        
        
        
        
        
        
        self.fc1 = nn.Linear(20 + dim_self_feat, 10)
        self.fc2 = nn.Linear(10, dim_out)


    
    
    
    
    def forward(self, g, self_feat):
        h = F.relu(self.gc1(g, g.ndata['feat']))
        h = F.relu(self.gc2(g, h))
        I = g.ndata['feat']
        hh1 = F.relu(self.ggc1(g, I))
        hh1m = torch.cat([hh1, I],dim=1)
        hh2 = F.relu(self.ggc2(g, hh1m))
        hh2m = torch.cat([hh2, hh1],dim=1)
        hh3 = F.relu(self.ggc3(g, hh2m))

        hh3m = torch.cat([hh3, hh2],dim=1)
        hh4 = F.relu(self.ggc4(g, hh3m))

        hh4m = torch.cat([hh4, hh3],dim=1)
        hh5 = F.relu(self.ggc5(g, hh4m))

        hh5m = torch.cat([hh5, hh4],dim=1)
        hh6 = F.relu(self.ggc6(g, hh5m))

        hh6m = torch.cat([hh6, hh5],dim=1)
        hh7 = F.relu(self.ggc7(g, hh6m))

        hh7m = torch.cat([hh7, hh6],dim=1)
        hh8 = F.relu(self.ggc8(g, hh7m))

        hh8m = torch.cat([hh8, hh7],dim=1)
        hh9 = F.relu(self.ggc9(g, hh8m))

        hh9m = torch.cat([hh9, hh8],dim=1)
        hh10 = F.relu(self.ggc10(g, hh9m))

        hh10m = torch.cat([hh10, hh9],dim=1)

        fusion = torch.cat([hh10m, h],dim=1)
        Fusion = F.relu(self.ggg(g, fusion))



        

        
        
        







        
        
        





        g.ndata['h'] = Fusion

        hg = dgl.mean_nodes(g, 'h')
        hg = torch.cat((hg, self_feat), dim=1)

        out = F.relu(self.fc1(hg))
        out = self.fc2(out)

        return out
