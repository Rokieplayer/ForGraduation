import dgl.function as fn
import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl



msg = fn.copy_src(src='h', out='m')


def reduce(nodes):
    accum = torch.mean(nodes.mailbox['m'], 1)

    return {'h': accum}


class NodeApplyModule(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(NodeApplyModule, self).__init__()
        self.linear = nn.Linear(dim_in, dim_out)

    def forward(self, node):
        h = self.linear(node.data['h'])

        return {'h': h}


class GCNLayer(nn.Module):
    def __init__(self, dim_in, dim_out):
        super(GCNLayer, self).__init__()
        self.apply_mod = NodeApplyModule(dim_in, dim_out)

    def forward(self, g, feature):
        g.ndata['h'] = feature
        g.update_all(msg, reduce)
        g.apply_nodes(func=self.apply_mod)

        return g.ndata.pop('h')

#GED는 너무 무거웠다. 그러면서 성능을 내는 곳이 한정적이었다. GResNet_EGCN_Short은 lipo 이외에선 성능이 좋았다. 일반화를 위해 Short_GED를 만든다.

class Net(nn.Module):
    def __init__(self, dim_in, dim_out, dim_self_feat):
        super(Net, self).__init__()

        self.gc1 = GCNLayer(dim_in, 100)
        self.gc2 = GCNLayer(100, 20)

        self.ggc1 = GCNLayer(dim_in, 100)
        self.ggc2 = GCNLayer(100 + dim_in, 64)
        self.ggc3 = GCNLayer(64 + 100 , 32)
        self.ggc4 = GCNLayer(64 + 32, 32)
        self.ggc5 = GCNLayer(32 + 32, 16)
        self.ggc6 = GCNLayer(32 + 16, 4)

        self.fc0 = nn.Linear(20 + 20, 20)






        self.fc1 = nn.Linear(20 + dim_self_feat, 10)
        self.fc2 = nn.Linear(10, dim_out)

    def forward(self, g, self_feat):
        h = F.relu(self.gc1(g, g.ndata['feat']))
        h = F.relu(self.gc2(g, h))
        
        I = g.ndata['feat']
        h1 = F.relu(self.ggc1(g, I))
        h1m = torch.cat([h1, I],dim=1)
        h2 = F.relu(self.ggc2(g, h1m))
        h2m = torch.cat([h2, h1],dim=1)
        h3 = F.relu(self.ggc3(g, h2m))

        h3m = torch.cat([h3, h2],dim=1)
        h4 = F.relu(self.ggc4(g, h3m))

        h4m = torch.cat([h4, h3],dim=1)
        h5 = F.relu(self.ggc5(g, h4m))

        h5m = torch.cat([h5, h4],dim=1)
        h6 = F.relu(self.ggc6(g, h5m))

        h6m = torch.cat([h6, h5],dim=1)


        Fusion = torch.cat([h, h6m],dim=1)
        
        
        
        
        
        
        
        
        
        g.ndata['h'] = Fusion

        hg = dgl.mean_nodes(g, 'h')
        hg = F.relu(self.fc0(hg))
        hg = torch.cat((hg, self_feat), dim=1)

        out = F.relu(self.fc1(hg))
        out = self.fc2(out)

        return out

