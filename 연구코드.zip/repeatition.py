import numpy as np
import pandas as pd
import time



def result(list, name, time, list_acc):
    ni = np.array(list); bi = np.array(list_acc)
    di = {}
    di['model'] = name
    di['avg_loss'] = np.mean(ni)
    di['std_loss'] = np.std(ni)
    di['max_loss'] = np.amax(ni)
    di['min_loss'] = np.amin(ni)
    di['length_loss'] = di['max_loss'] - di['min_loss']
    #di['avg_accuracy'] = np.mean(bi)

    di['avg_time'] = time
    return di

models = [model_EGCN, model_GResNet_EGCN, model_GResNet_EGCN_Short, model_GResNet_1,
            model_GResNet_2, model_GResNet_3, model_raw_2, model_raw_3, model_raw_6]

models_name = ['EGCN', 'GResNet_EGCN', 'GResNet_EGCN_Short', 'GResNet_1',
            'GResNet_2', 'GResNet_3', 'raw_2', 'raw_3', 'raw_6']            

def ppap(models= models, trial=10, models_name = models_name): 
    tax = 0.0; acc = 0.0
    for i, model in enumerate(models):
        print(f'-----{models_name[i]}-----')
        time_0 = time.time()
        list_1 =[]; list_2 = []; list_acc=[]
        for j in range(trial):
            tax, acc = trainer.cross_validation(dataset, model, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel, accs=[])
            list_1.append(tax)
            list_acc.append(acc)
        time_1 = (time.time() - time_0) / trial 
        list_2.append(result(list_1, models_name[i], time_1, list_acc))
    for j in range(len(models)):
        print(list_2[j])
        print('\n')



trial = 10
tax = 0.0

print('--------- EGCN ---------')
time_0 = time.time()
list_1 = []
list_2 = []
for i in range(trial):
    tax = trainer.cross_validation(dataset, model_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'EGCN', time_1))



print('--------- GResNet_EGCN(naive) ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax = trainer.cross_validation(dataset,  model_GResNet_EGCN, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'GResNet_EGCN(naive)', time_1))

print('--------- GResNet_EGCN_Short ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_EGCN_Short, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_EGCN_Short', time_1))


print('--------- GResNet_1 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_1, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_1', time_1))


print('--------- GResNet_2 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial   
list_2.append(result(list_1, 'GResNet_2', time_1))

print('--------- GResNet_3 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_GResNet_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'GResNet_3', time_1))


print('--------- raw_2 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_2, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_2', time_1))


print('--------- raw_3 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_3, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_3', time_1))


print('--------- raw_6 ---------')
time_0 = time.time()
list_1.clear()
for i in range(trial):
    tax= trainer.cross_validation(dataset,  model_raw_6, criterion, k, batch_size, max_epochs, trainer.train_emodel, trainer.test_emodel, collate_emodel)
    list_1.append(tax)
time_1 = (time.time() - time_0) / trial  
list_2.append(result(list_1, 'raw_6', time_1))


for i in range(trial):
    print(list_2[i])
    print('\n')